// config.client.js
const config = {
  OMIE_WEBHOOK_TOKEN: '11e503358e3ae0bee91053faa1323629',
  OMIE_APP_KEY:    '3917057082939',
  OMIE_APP_SECRET: '11e503358e3ae0bee91053faa1323629',
};

export default config;